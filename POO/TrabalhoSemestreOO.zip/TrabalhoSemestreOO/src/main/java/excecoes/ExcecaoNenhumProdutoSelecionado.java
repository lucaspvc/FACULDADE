package excecoes;

public class ExcecaoNenhumProdutoSelecionado extends Exception{
    public ExcecaoNenhumProdutoSelecionado (String mensagem){
        super(mensagem);
    }
}
