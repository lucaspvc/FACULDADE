package excecoes;

public class ExcecaoCamposObrigatoriosVazios extends Exception{
    public ExcecaoCamposObrigatoriosVazios (String mensagem){
        super(mensagem);
    }

}
